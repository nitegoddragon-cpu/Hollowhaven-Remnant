from pathlib import Path
import cv2
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ATLAS = Path("/mnt/data/hollowhaven_sources/Hollowhaven Remnant Sprite Atlas.png")
OUT = ROOT / "app/src/main/assets/hollowhaven/sprites"

# Panel image regions only. The atlas has labels below the artwork, so each
# row is cropped independently instead of treating the label strip as a frame.
PANELS = [
    (428, 1001, [(43, 108), (129, 210)], 10),
    (1003, 1530, [(43, 108), (129, 210)], 10),
    (8, 668, [(289, 346), (376, 450)], 10),
    (669, 1089, [(289, 360)], 10),
    (1090, 1530, [(289, 360)], 10),
    (8, 510, [(495, 538)], 10),
    (510, 1032, [(495, 538)], 10),
    (1033, 1530, [(495, 538)], 10),
    (8, 509, [(620, 670)], 10),
    (510, 1031, [(620, 670)], 10),
    (1033, 1530, [(620, 670)], 10),
    (8, 529, [(747, 796)], 10),
    (530, 1032, [(747, 796)], 10),
    (1033, 1530, [(747, 796)], 10),
    (8, 526, [(905, 953)], 10),
    (527, 1032, [(905, 953)], 10),
    (1033, 1530, [(905, 953)], 10),
]


def segment(tile_rgb: np.ndarray) -> np.ndarray:
    h, w = tile_rgb.shape[:2]
    hsv = cv2.cvtColor(tile_rgb, cv2.COLOR_RGB2HSV)

    # High-value/gold/white pixels are reliable Remnant foreground seeds.
    # Dilating those seeds lets GrabCut recover darker green armor without
    # requiring a generic dragon silhouette.
    seeds = ((hsv[:, :, 2] > 145) & ((hsv[:, :, 1] > 50) | (hsv[:, :, 2] > 180))).astype(np.uint8)
    seeds = cv2.morphologyEx(seeds, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    probable = cv2.dilate(seeds, np.ones((7, 7), np.uint8), iterations=1)

    mask = np.full((h, w), cv2.GC_PR_BGD, np.uint8)
    mask[probable > 0] = cv2.GC_PR_FGD
    border = max(1, min(h, w) // 12)
    mask[:border, :] = cv2.GC_BGD
    mask[-border:, :] = cv2.GC_BGD
    mask[:, :border] = cv2.GC_BGD
    mask[:, -border:] = cv2.GC_BGD
    mask[seeds > 0] = cv2.GC_FGD

    bgd = np.zeros((1, 65), np.float64)
    fgd = np.zeros((1, 65), np.float64)
    cv2.grabCut(tile_rgb, mask, None, bgd, fgd, 5, cv2.GC_INIT_WITH_MASK)
    alpha = np.where((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)

    # Remove isolated specks while preserving detached elemental effects.
    n, labels, stats, _ = cv2.connectedComponentsWithStats(alpha, 8)
    if n > 1:
        keep = np.zeros_like(alpha)
        areas = stats[1:, cv2.CC_STAT_AREA]
        for lab in (np.argsort(areas)[::-1] + 1)[:10]:
            if stats[lab, cv2.CC_STAT_AREA] >= max(6, int(h * w * 0.004)):
                keep[labels == lab] = 255
        alpha = keep
    return cv2.morphologyEx(alpha, cv2.MORPH_CLOSE, np.ones((2, 2), np.uint8))


def make_frame(tile_rgb: np.ndarray) -> Image.Image:
    alpha = segment(tile_rgb)
    ys, xs = np.where(alpha > 0)
    if len(xs) == 0:
        return Image.new("RGBA", (192, 192), (0, 0, 0, 0))

    pad = 1
    x0, x1 = max(0, xs.min() - pad), min(tile_rgb.shape[1], xs.max() + pad + 1)
    y0, y1 = max(0, ys.min() - pad), min(tile_rgb.shape[0], ys.max() + pad + 1)
    rgb = tile_rgb[y0:y1, x0:x1]
    a = alpha[y0:y1, x0:x1]

    # Same canvas and same visual scale for every frame. Bottom-aligning keeps
    # walking feet from bouncing while the overlay engine handles jumps/falls.
    scale = min(184.0 / rgb.shape[1], 184.0 / rgb.shape[0])
    nw = max(1, round(rgb.shape[1] * scale))
    nh = max(1, round(rgb.shape[0] * scale))
    rgb = cv2.resize(rgb, (nw, nh), interpolation=cv2.INTER_LANCZOS4)
    a = cv2.resize(a, (nw, nh), interpolation=cv2.INTER_AREA)

    canvas = np.zeros((192, 192, 4), np.uint8)
    x = (192 - nw) // 2
    y = max(2, 188 - nh)
    canvas[y:y + nh, x:x + nw, :3] = rgb
    canvas[y:y + nh, x:x + nw, 3] = a
    return Image.fromarray(canvas, "RGBA")


def main():
    if not ATLAS.exists():
        raise SystemExit(f"Atlas not found: {ATLAS}")
    OUT.mkdir(parents=True, exist_ok=True)
    atlas = np.array(Image.open(ATLAS).convert("RGB"))
    index = 1
    for x0, x1, rows, cols in PANELS:
        cell_w = (x1 - x0) / cols
        for y0, y1 in rows:
            cell_h = y1 - y0
            for c in range(cols):
                xa = round(x0 + c * cell_w)
                xb = round(x0 + (c + 1) * cell_w)
                tile = atlas[y0:y0 + cell_h, xa:xb]
                make_frame(tile).save(OUT / f"f{index:03}.png")
                index += 1
    if index != 201:
        raise SystemExit(f"Expected 200 frames, generated {index - 1}")
    print("Generated 200 clean 192x192 RGBA frames")

if __name__ == "__main__":
    main()
