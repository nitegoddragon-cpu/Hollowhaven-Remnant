#!/usr/bin/env python3
from pathlib import Path
import re, sys, zipfile, xml.etree.ElementTree as ET
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'app'
JAVA = APP / 'src/main/java/com/hollowhaven/remnant'
ASSET = APP / 'src/main/assets/hollowhaven'
RES = APP / 'src/main/res'
WORKFLOW = ROOT / '.github/workflows/build-apk.yml'

def fail(msg):
    print('FAIL:', msg); raise SystemExit(1)
def ok(msg): print('PASS:', msg)

# Manifest / resources
try:
    ET.parse(APP / 'src/main/AndroidManifest.xml')
except Exception as e: fail(f'Manifest XML: {e}')
ok('Manifest XML parses')

# Built-in sprite integrity
frames = sorted((RES / 'drawable-nodpi').glob('f*.png'))
if len(frames) != 200: fail(f'expected 200 built-in frames, found {len(frames)}')
for f in frames:
    with Image.open(f) as im:
        if im.size != (192, 192): fail(f'{f.name}: size {im.size}')
        if im.mode != 'RGBA': fail(f'{f.name}: mode {im.mode}')
ok('200 built-in 192x192 RGBA frames')

# Source delimiter balance, useful for Java syntax corruption
for f in [JAVA/'MainActivity.java', JAVA/'RemnantOverlayService.java']:
    s=f.read_text()
    for a,b in [('(',')'),('{','}'),('[',']')]:
        if s.count(a)!=s.count(b): fail(f'{f.name}: {a}{b} imbalance {s.count(a)} vs {s.count(b)}')
ok('Java delimiter balance')

# Required production seams
main=(JAVA/'MainActivity.java').read_text()
svc=(JAVA/'RemnantOverlayService.java').read_text()
html=(ASSET/'index.html').read_text()
wf=WORKFLOW.read_text()
checks={
    'video picker': 'MediaMetadataRetriever' in main and 'ACTION_OPEN_DOCUMENT' in main,
    'folder importer': 'ACTION_OPEN_DOCUMENT_TREE' in main and 'collectImages' in main,
    'ZIP importer': 'ZipInputStream' in main and 'safeZipPath' in main,
    'staged rollback': 'replaceImported' in main and 'importing' in main,
    'AI generator routes': 'upsampler.co' in main and 'nifty-vid' in main,
    'speed control bridge': 'setSpeed' in main,
    'size control bridge': 'setSize' in main,
    'non-sticky foreground service': 'START_NOT_STICKY' in svc,
    'runtime resize': 'resizePetWindow' in svc,
    'battery settings bridge': 'openBatterySettings' in main and 'ACTION_APPLICATION_DETAILS_SETTINGS' in main,
    'direction-aware custom mirroring': 'shouldMirror' in svc and 'walk_right' in svc and 'walk_left' in svc,
    'overlay service': 'TYPE_APPLICATION_OVERLAY' in svc,
    'window context API30+': 'createWindowContext' in svc and 'createDisplayContext' in svc,
    'special-use FGS': 'FOREGROUND_SERVICE_TYPE_SPECIAL_USE' in svc,
    'HTML controls': 'tuneSpeed' in html and 'tuneSize' in html,
    'API 36': 'compileSdk 36' in (APP/'build.gradle').read_text() and 'targetSdk 36' in (APP/'build.gradle').read_text(),
    'AGP 8.13.2': "version '8.13.2'" in (ROOT/'build.gradle').read_text(),
    'Gradle 8.13 workflow': "gradle-version: '8.13'" in wf,
    'optional signing is safe': 'SIGNING_READY' in wf and "if: env.SIGNING_READY == 'true'" in wf,
}
for name, good in checks.items():
    if not good: fail(name)
ok(f'{sum(checks.values())} feature/build checks')

# Ensure no obvious absolute/traversal paths in source ZIP handling
for token in ['../', '..\\']:
    if token in main.split('safeZipPath',1)[1].split('private String firstAnimationFolder',1)[0]:
        fail('unsafe ZIP traversal token in ZIP sanitization section')
ok('ZIP path hardening present')

# Verify package can be zipped and reopened
out=ROOT.parent/'Hollowhaven_Remnant_QA_tmp.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for p in ROOT.rglob('*'):
        if p.is_file(): z.write(p, p.relative_to(ROOT))
with zipfile.ZipFile(out) as z:
    bad=z.testzip()
    if bad: fail(f'ZIP integrity: {bad}')
out.unlink(missing_ok=True)
ok('Project ZIP integrity')
print('ALL LOCAL QA CHECKS PASSED')
