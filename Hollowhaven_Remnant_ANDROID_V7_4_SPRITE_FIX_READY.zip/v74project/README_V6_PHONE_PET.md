# Hollowhaven Remnant Android V6

Phone-pet hardening build. This version keeps the native Android overlay architecture and adds multiple ways to turn Hollowhaven artwork or AI motion into a real screen pet.

## V6 additions
- Native cross-app overlay pet remains the core engine.
- Screen-off pause and screen-on resume so animation work stops while the display is off.
- Notification now includes a REST action to stop the pet.
- Tap the pet for a happy reaction; drag it to reposition it.
- Removed the notification-permission gate from START PET. Android can run the foreground service without requiring POST_NOTIFICATIONS at startup; the app still declares the permission so newer Android versions can show the notification when allowed.
- Pet pack ZIP import.
- ZIP packs can preserve animation-state folders such as `idle`, `walk`, `walk_left`, `walk_right`, `jump`, `fall`, `climb_up`, `climb_down`, `sleep`, and `happy`.
- State-aware custom animation selection with fallback to `idle` or a flat/default sequence.
- RESET TO REMNANT button.
- Existing folder import and AI-video-to-frames import remain.
- Existing free Wan AI Motion Lab route remains.

## Intended phone flow
1. Install the APK.
2. Open Hollowhaven Pet Creator.
3. Grant Display over other apps.
4. Press START PET.
5. The Remnant appears above the home screen and other apps.
6. Drag it, tap it, and let it wander.
7. For AI motion: generate an MP4 with the free Wan route, then IMPORT AI VIDEO. The phone converts the real video into animation frames and the native overlay displays those frames.
8. For creator packs: IMPORT PET PACK ZIP. Keep animation states in named folders.

## Important build status
This package is source/build-ready. It is NOT an APK claim. The current ChatGPT container does not have a usable Android SDK + Gradle toolchain, so an actual APK compile and phone installation must be performed by the included GitHub Actions workflow or another Android build environment.

## GitHub build chain
The included workflow uses:
- JDK 17
- Android SDK platform 35
- Build Tools 35.0.0
- Gradle 8.9
- Android Gradle Plugin 8.7.3

The workflow uploads `app-debug.apk` as a GitHub Actions artifact.
