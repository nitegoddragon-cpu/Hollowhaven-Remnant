# Hollowhaven Remnant V7.3 Web + Ramus Build Check

## Web findings
- Android Gradle Plugin 8.13 supports API 36.1 with Gradle 8.13, Build Tools 35.0.0 and JDK 17.
- Android 15 tightened background foreground-service starts for apps using SYSTEM_ALERT_WINDOW: if an app starts the FGS from the background, it needs a currently visible TYPE_APPLICATION_OVERLAY window unless another exemption applies.
- Hollowhaven starts the pet from the visible MainActivity, checks Settings.canDrawOverlays(), and creates TYPE_APPLICATION_OVERLAY in the service. It does not use BOOT_COMPLETED to start the pet.
- SYSTEM_ALERT_WINDOW is the correct Android permission for TYPE_APPLICATION_OVERLAY.
- Free cloud source-build routes found: AndroidForge (GitHub Actions based) and other GitHub-based builders. They still require a GitHub account/token or repository setup; no claim of a completed remote build is made here.

## Ramus test plan
Once a real APK exists:
1. Install and launch.
2. Snapshot the main creator screen.
3. Grant overlay permission through Android settings.
4. Start the Remnant.
5. Verify the pet appears above the launcher and another app.
6. Drag the pet.
7. Wait for autonomous idle/walk/jump/edge behavior.
8. Press HOME and verify the pet remains visible.
9. Press POWER/screen off and on; verify the service remains stable.
10. Change size and speed, then reload.
11. Import a PNG/JPG pet pack and verify animation selection.
12. Import an AI MP4/MOV and verify frame extraction.
13. Inspect logcat for HollowhavenPet and HollowhavenMain errors.
14. Repeat after every fix.

## Honest build status
Local environment still has Java 21 but no Gradle, Android SDK, ADB, or sdkmanager. Therefore this workspace cannot honestly claim a compiled APK. The project is prepared for a cloud Android build.
