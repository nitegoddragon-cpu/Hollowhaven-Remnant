# Hollowhaven Remnant V7.3 Plugin + QA Update

Version: 2.4.1 (versionCode 8)

## Added
- Native pet size slider with immediate overlay resize.
- Native walk-speed slider with persistent preference.
- Foreground service uses START_STICKY for better recovery after process pressure; explicit user stop still shuts it down.
- Two free Wan-based image-to-video entry points: Upsampler and NiftyVid. The app only opens these services; it does not claim to run AI inference locally.
- Local QA script at `tools/qa_project.py`.
- Optional signing workflow no longer depends on a GitHub `if:` expression that directly reads secrets. It prepares a signing flag through `GITHUB_ENV` and skips signing cleanly when keys are absent.

## Verified locally
- Manifest XML parses.
- 200 built-in 192x192 RGBA frames verified.
- Java delimiter balance verified.
- 16 feature/build checks passed.
- ZIP traversal hardening checks passed.
- Project ZIP integrity passed.
- HTML JavaScript syntax passed in Node.
- Workflow YAML parsed successfully.
- QA was run twice with identical pass results.

## Build toolchain
- Android Gradle Plugin 8.13.2
- Gradle 8.13
- JDK 17 in CI
- compileSdk/targetSdk 36
- SDK Build Tools 35.0.0

## Important limitation
This workspace still does not contain a local Android SDK/Gradle/ADB toolchain, so no local APK compilation or real-device install is claimed. The GitHub Actions workflow is prepared to build the debug APK, unsigned release APK/AAB, and optionally signed release outputs when the owner supplies a persistent upload keystore.
