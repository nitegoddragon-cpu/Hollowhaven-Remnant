# Hollowhaven Remnant V7.1 Phone App

This is the native Android direction for the real Google Play app.

## V7.1 fixes
- Targets Android 16 / API 36 for current Google Play submission requirements.
- Uses AGP 8.11.1 with Gradle 8.13 and JDK 17 in the build workflow.
- Builds both a debug APK and a release AAB artifact.
- Adds a launcher icon and Play Store 512px icon source.
- Requests notification permission before first pet launch on Android 13+; the pet still starts if the user denies it.
- Keeps the explicit overlay permission gate.
- Stops animation work while the screen is off and resumes cleanly when the screen turns on.
- Adds a native pet reload action so importing/resetting a pet updates an already-running overlay instead of requiring a restart.
- Preserves aspect ratio for imported AI video frames instead of stretching 16:9 video into a square pet.
- Converts AI video frames to lightweight PNG sprites, caps imports, and samples the first 15 seconds at up to 12 FPS.
- Performs conservative corner-connected background removal on AI video frames so the imported creature can sit on the screen without an opaque video rectangle when the source has a reasonably uniform background.
- Limits imported image entry size and normalizes images to a maximum 320px dimension to reduce memory crashes.
- Preserves first-level animation folders such as `idle`, `walk`, `walk_left`, `walk_right`, `jump`, `fall`, `climb_up`, `climb_down`, `sleep`, and `happy` when importing a folder.
- Renumbers imported folder frames per animation sequence so `1, 2, 10` cannot become `1, 10, 2` due to filename sorting.
- Hardens ZIP paths against traversal and unsafe path components.
- Caps imported animation sets at 240 frames.
- Keeps the original 200 Remnant frames.
- Fixes a ZIP-import staging bug that could write into the live pet folder before activation. ZIP imports now stage completely before replacement.
- Makes pet replacement rollback-safe so a failed activation does not destroy the current pet.
- Prevents two imports from running at the same time and fighting over the staging directory.
- Accepts common ZIP layouts with a top-level character folder such as `Remnant/idle/...` and maps the animation folders correctly.
- Refuses an empty folder/ZIP import instead of replacing a working pet with an empty library.
- Corrects the creator status message so it reports that a running pet is refreshed automatically after a successful import.


## Build status
The source package has been checked through another full verification pass after the V7.1 fixes with the included project verification script. XML and embedded JavaScript syntax were also checked locally.

This workspace still does not contain the Android SDK/Gradle toolchain, so no local APK/AAB compilation is claimed. The GitHub Actions workflow is the actual build path and will run lint, build the debug APK, build the release AAB, and upload both artifacts.

## Play release signing
The checked-in workflow intentionally does not contain a private signing key. A production Google Play release must be signed with the developer's upload key. The next release step is to add a private upload keystore through the build service's encrypted secrets, never into this source ZIP.
