# Hollowhaven Remnant V7.4

Sprite pipeline repair focused on the phone pet visuals.

- Re-extracts all 200 Remnant frames directly from the source atlas.
- Removes frame-number labels and atlas cell borders from the frame crop.
- Uses transparent RGBA sprites instead of displaying the whole atlas tile.
- Normalizes frames to a common 320x320 canvas for smoother animation alignment.
- Keeps the existing native Android overlay engine and V7.3 behavior unchanged.
- Version 2.5.0 / versionCode 8.

This package is source/build input. A compiled APK must be produced by the GitHub Actions workflow before claiming a new APK.
