# Hollowhaven Remnant Android V5 AI Motion Bridge

This build combines the existing native Shimeji-style Android overlay with an external AI image-to-video workflow.

## New V5 path
1. Open the Hollowhaven app.
2. Open **AI MOTION LAB**.
3. Open the free Wan-based generator.
4. Upload the exact Remnant reference image.
5. Use the provided preservation/motion prompt.
6. Save the generated MP4/MOV to the phone.
7. Return to Hollowhaven and choose **IMPORT AI VIDEO**.
8. The app extracts a lightweight 12 FPS sprite sequence (up to 180 frames).
9. Start the native overlay pet. The imported sequence becomes the active pet animation.

## Existing features preserved
- Native Android overlay service
- Display-over-other-apps permission
- Autonomous wandering, edge turns, climbing, falling, jumping, idle, happy and sleep actions
- 200 built-in Remnant frames
- Folder import of PNG/JPG animation frames
- WebView creator and native bridge

## Important
The AI generator remains external. Hollowhaven does not pretend to generate an AI video locally. It imports the real generated video and converts it into animation frames for the phone pet.
