Hollowhaven Remnant Android V4

Hybrid build: WebView creator + native Android overlay pet engine.

V4 fixes carried forward:
- Removed duplicate loadPreferences() Java method that could prevent compilation.
- Fixed recursive Android folder import to preserve the original tree URI while traversing child folders.
- Sorts imported animation frames by display filename.
- Safely handles Android 13 notification permission before starting the pet.
- Refreshes overlay state when returning from Android settings.
- Native overlay service catches runtime failures and cleans itself up instead of crashing the app.
- Keeps Android 14+ special-use foreground-service type guarded by API level.
- Preserves 200 built-in Remnant frames.

This is source code. No APK is claimed unless an Android SDK build is actually performed.

## GitHub APK build
A workflow is included at `.github/workflows/build-apk.yml`. Put this project in a GitHub repository, then open **Actions → Build Hollowhaven Remnant APK → Run workflow**. A push to `main` also triggers the build. The workflow produces `app-debug.apk` as a downloadable artifact.
