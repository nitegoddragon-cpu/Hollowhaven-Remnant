# Hollowhaven Remnant V7.1 verification

Date: 2026-10-21

## Static verification
- Project verifier pass after V7.1 fixes: PASS
- ZIP/package integrity pass: PASS
- Java lexical/bracket balance: PASS for MainActivity and RemnantOverlayService
- XML parse: PASS for manifest, values, and launcher vector
- Embedded WebView JavaScript `node --check`: PASS
- Built-in animation frames: 200/200 present
- Built-in frame dimensions: 192x192
- Launcher icon densities: present
- Target SDK: 36
- Compile SDK: 36
- Android Gradle Plugin: 8.11.1
- Gradle workflow: 8.13
- JDK workflow: 17

## Runtime bug fixes checked into V7.1
1. Screen-off animation loop now pauses instead of continuing to update the overlay.
2. Running pet reload/reset no longer tries to start a foreground service from an import worker thread. A package-scoped broadcast refreshes the already-running service.
3. Imported AI video keeps its original aspect ratio in the overlay instead of stretching into a square.
4. AI video frames are normalized to lightweight PNG sprites and conservatively remove corner-connected uniform backgrounds.
5. Folder imports preserve first-level animation state folders and renumber frames per sequence.
6. Image imports are size-limited and capped at 240 frames.
7. ZIP imports reject unsafe traversal/path components.
8. Android 13+ notification permission is handled before first pet launch, without making the pet unusable when permission is denied.
9. A real launcher icon and Play Store icon source were added.
10. Build workflow now runs lint, debug APK, and release AAB tasks.

## Not yet honestly claimed
This workspace still lacks the Android SDK/Gradle build chain and a physical Android device/emulator. Therefore no APK/AAB compilation or device test is claimed here. The GitHub Actions workflow is configured to perform the real build and artifact verification.

11. ZIP imports now stage into a temporary directory and activate atomically with rollback.
12. Concurrent imports are blocked to protect the staging directory.
13. Common top-level character-folder ZIP layouts are normalized.
14. Empty imports no longer replace a working pet.
15. WebView JavaScript syntax: PASS.
16. Sprite consistency: 200/200, 192x192 RGBA.
17. Final V7.1 ZIP integrity: PASS.
