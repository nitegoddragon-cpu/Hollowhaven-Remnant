# Hollowhaven Remnant V4 Build Check

Prepared for a real Android build. This workspace does not contain the Android SDK/Gradle toolchain, so no APK is claimed as compiled here.

## Static checks completed
- Android project structure present.
- AGP 8.7.3 project configuration present.
- compileSdk 35 / targetSdk 35 / minSdk 26.
- Java source brace and parenthesis balance checked.
- No duplicate Java method definitions found.
- Android XML resources parse successfully.
- All 200 Remnant PNG frames decode successfully.
- All 200 frames are 192x192 RGBA images with transparency.
- Frame sequence is complete: f001.png through f200.png.

## Real build route
The included GitHub Actions workflow uses Java 17, Gradle 8.9, Android SDK platform 35 and build-tools 35.0.0, then runs `assembleDebug` and uploads the APK as an artifact.

This is a build-ready source package, not a falsely claimed APK.
