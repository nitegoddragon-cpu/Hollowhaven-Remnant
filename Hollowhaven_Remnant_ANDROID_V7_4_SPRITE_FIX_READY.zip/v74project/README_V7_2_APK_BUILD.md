# Hollowhaven Remnant V7.2 APK Build

Version 2.4.0. This package is prepared for a real Android build.

## Outputs
- Debug APK: installable for device testing.
- Unsigned release APK: packaging check only.
- Unsigned AAB: Play packaging check only.
- Signed release APK/AAB: produced only when the build environment supplies the owner's upload keystore secrets.

## Toolchain
- JDK 17
- Android API 36
- AGP 8.13.2
- Gradle 8.13
- Android Build Tools 35.0.0

The workflow verifies the debug APK with apksigner.

## Important
Do not publish an artifact signed with a temporary or unknown key. For Google Play, use a persistent upload keystore that you control.
