# Hollowhaven Remnant 2.6.0 Build Path

Purpose: overlay the 2.6.0 source onto the existing V7.4 sprite project, preserving the 200 built-in Remnant PNG frames already stored in the repository ZIP.

## Files to upload to the GitHub repository
Copy everything under `overlay/` to the repository root, preserving paths.

- app/build.gradle
- app/src/main/java/com/hollowhaven/remnant/AiVideoWorkerClient.java
- app/src/main/java/com/hollowhaven/remnant/MainActivity.java
- app/src/main/java/com/hollowhaven/remnant/RemnantOverlayService.java
- app/src/main/assets/hollowhaven/index.html

## Build design
1. GitHub Actions checks out the repository.
2. It extracts Hollowhaven_Remnant_ANDROID_V7_4_SPRITE_FIX_READY_FIXED.zip.
3. It copies the overlay files above over the extracted project.
4. It runs QA.
5. It runs lint.
6. It builds debug APK, release APK and AAB.
7. It verifies the debug APK with apksigner.
8. It uploads all artifacts.

## Important
Do not upload or commit a WaveSpeed API key. Enter the key at runtime only, or use a secure server bridge.
